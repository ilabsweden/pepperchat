
import sys
if sys.version_info[0] > 2:
    from oaichat.openaichat import OaiChat

